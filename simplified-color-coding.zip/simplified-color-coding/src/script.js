alert ("This is an example ofhow to make images on code. (simplified.)")
