# Simplified color coding.

A Pen created on CodePen.io. Original URL: [https://codepen.io/Hacer00700/pen/QWQYOxE](https://codepen.io/Hacer00700/pen/QWQYOxE).

